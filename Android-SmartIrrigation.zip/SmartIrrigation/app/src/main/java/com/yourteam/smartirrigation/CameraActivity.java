package com.yourteam.smartirrigation;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class CameraActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_camera);

        // 获取树莓派IP
        String raspiIp = getIntent().getStringExtra("RASPI_IP");

        // 配置WebView显示摄像头画面
        WebView webView = findViewById(R.id.webview_camera);
        webView.setWebViewClient(new WebViewClient());
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setLoadWithOverviewMode(true);
        webView.getSettings().setUseWideViewPort(true);

        // 加载摄像头视频流
        String videoUrl = "http://" + raspiIp + ":5000/video_feed";
        webView.loadUrl(videoUrl);
    }
}