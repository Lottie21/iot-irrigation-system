package com.yourteam.smartirrigation; // ← 改成你项目的实际包名

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

import android.view.MotionEvent;
import android.content.Intent;

import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    private TextView tvSent, tvRecv;
    private EditText etInput;
    private Button btnConnect, btnSend;
    private DatagramSocket recvSocket = null;
    private volatile boolean isReceiving = false;

    // TODO: 替换为你的 Raspi IP
    private static final String RASPI_IP = "172.20.10.2"; // 树莓派 IPIPIP
    private static final int RASPI_PORT = 8003; //port
    private static final int LOCAL_RECV_PORT = 8888;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 1) 绑定控件（id 必须与 activity_main.xml 中一致）
        tvSent = findViewById(R.id.textView_sent);
        tvRecv = findViewById(R.id.textView_recv);
        etInput = findViewById(R.id.editText);
        btnConnect = findViewById(R.id.button_connect);
        btnSend = findViewById(R.id.button_send);
        Button btnWater = findViewById(R.id.button_water);
        Button btnCamera = findViewById(R.id.button_camera);
        Button btnStats = findViewById(R.id.button_stats);
        Button btnHistory = findViewById(R.id.button_history);
        Button btnReset = findViewById(R.id.button_reset);

        btnStats.setOnClickListener(v -> {
            // 请求统计数据
            new Thread(() -> {
                try {
                    InetAddress addr = InetAddress.getByName(RASPI_IP);
                    byte[] data = "GET_STATS".getBytes();
                    DatagramPacket packet = new DatagramPacket(data, data.length, addr, RASPI_PORT);

                    DatagramSocket socket = new DatagramSocket();
                    socket.setSoTimeout(3000);
                    socket.send(packet);

                    // 接收响应
                    byte[] buf = new byte[256];
                    DatagramPacket recvPacket = new DatagramPacket(buf, buf.length);
                    socket.receive(recvPacket);
                    String result = new String(recvPacket.getData(), 0, recvPacket.getLength());

                    socket.close();

                    // 解析并显示
                    runOnUiThread(() -> {
                        String[] parts = result.split("\\|");
                        StringBuilder stats = new StringBuilder("📊 累计用量统计\n\n");

                        for (String part : parts) {
                            if (part.startsWith("WATER:")) {
                                stats.append("用水量: ").append(part.substring(6)).append(" L\n");
                            } else if (part.startsWith("WCOST:")) {
                                stats.append("水费: ").append(part.substring(6)).append(" MOP\n");
                            } else if (part.startsWith("ENERGY:")) {
                                stats.append("用电量: ").append(part.substring(7)).append(" Wh\n");
                            } else if (part.startsWith("ECOST:")) {
                                stats.append("电费: ").append(part.substring(6)).append(" MOP\n");
                            }
                        }

                        // 弹窗显示
                        new android.app.AlertDialog.Builder(MainActivity.this)
                                .setMessage(stats.toString())
                                .setPositiveButton("确定", null)
                                .show();
                    });

                } catch (Exception e) {
                    e.printStackTrace();
                    runOnUiThread(() -> tvSent.setText("统计查询失败: " + e.getMessage()));
                }
            }).start();
        });

        btnCamera.setOnClickListener(v -> {
    	 // 打开新Activity显示视频
    		  Intent intent = new Intent(MainActivity.this, CameraActivity.class);
    		  intent.putExtra("RASPI_IP", RASPI_IP);
    	  	  startActivity(intent);
        });

        Button btnFaces = findViewById(R.id.button_faces);
        btnFaces.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, FacePhotosActivity.class);
            intent.putExtra("RASPI_IP", RASPI_IP);
            startActivity(intent);
        });

        // 2) 连接按钮：开启本地 UDP 接收（演示用，可打印接收内容到界面）
        btnConnect.setOnClickListener(v -> {
            if (!isReceiving) {
                // 连接
                btnConnect.setText("DISCONNECT");
                btnConnect.setBackgroundColor(0xFFFF6600); // 橙色
                tvRecv.setText("listening on " + LOCAL_RECV_PORT + "...");
                isReceiving = true;
                startRecvThread();
            } else {
                // 断开
                btnConnect.setText("CONNECT");
                btnConnect.setBackgroundColor(0xFF4DB8FF); // 恢复蓝色
                isReceiving = false;
                if (recvSocket != null && !recvSocket.isClosed()) {
                    recvSocket.close();
                }
                tvRecv.setText("已断开连接");
            }
        });

        // 3) 发送按钮：把输入框内容通过 UDP 发到 Raspi:8003
        btnSend.setOnClickListener(v -> {
            String msg = etInput.getText().toString();
            if (msg.isEmpty()) msg = "(empty)";
            tvSent.setText(msg);
            sendUdp(msg);

            // 4) 浇水按钮：长按浇水，松开停止
            btnWater.setOnTouchListener((view, event) -> {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        // 按下：开始浇水
                        sendUdp("PUMP_ON");
                        btnWater.setBackgroundColor(0xFF00AA00); // 变绿色
                        tvSent.setText("🚿 正在浇水...");
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        // 松开：停止浇水
                        sendUdp("PUMP_OFF");
                        btnWater.setBackgroundColor(0xFF4DB8FF); // 恢复蓝色
                        tvSent.setText("💧 已停止浇水");
                        break;
                }
                return true;
            });
            btnHistory.setOnClickListener(view -> {
                new Thread(() -> {
                    try {
                        InetAddress addr = InetAddress.getByName(RASPI_IP);
                        byte[] data = "GET_HISTORY".getBytes();
                        DatagramPacket packet = new DatagramPacket(data, data.length, addr, RASPI_PORT);

                        DatagramSocket socket = new DatagramSocket();
                        socket.setSoTimeout(3000);
                        socket.send(packet);

                        // text
                        byte[] buf = new byte[4096];
                        DatagramPacket recvPacket = new DatagramPacket(buf, buf.length);
                        socket.receive(recvPacket);
                        String text = new String(recvPacket.getData(), 0, recvPacket.getLength(), "UTF-8");
                        socket.close();

                        runOnUiThread(() -> {
                            // 弹窗显示
                            new android.app.AlertDialog.Builder(MainActivity.this)
                                    .setMessage(text.toString())
                                    .setPositiveButton("确定", null)
                                    .show();
                        });

                    } catch (Exception e) {
                        e.printStackTrace();
                        runOnUiThread(() -> tvSent.setText("获取历史失败: " + e.getMessage()));
                    }
                }).start();
            });
            btnReset.setOnClickListener(views -> {
                new android.app.AlertDialog.Builder(this)
                        .setTitle("⚠️ 清零确认")
                        .setMessage("确定要清空所有统计数据吗？\n此操作不可恢复！")
                        .setPositiveButton("确定清零", (dialog, which) -> {
                            new Thread(() -> {
                                try {
                                    InetAddress addr = InetAddress.getByName(RASPI_IP);
                                    byte[] data = "RESET_STATS".getBytes();
                                    DatagramPacket packet = new DatagramPacket(data, data.length, addr, RASPI_PORT);

                                    DatagramSocket socket = new DatagramSocket();
                                    socket.setSoTimeout(3000);
                                    socket.send(packet);

                                    // 接收确认响应
                                    byte[] buf = new byte[128];
                                    DatagramPacket recvPacket = new DatagramPacket(buf, buf.length);
                                    socket.receive(recvPacket);
                                    String response = new String(recvPacket.getData(), 0, recvPacket.getLength());
                                    socket.close();

                                    runOnUiThread(() -> {
                                        if (response.equals("OK")) {
                                            tvSent.setText("✅ 统计数据已清零");
                                        } else {
                                            tvSent.setText("清零失败");
                                        }
                                    });

                                } catch (Exception e) {
                                    e.printStackTrace();
                                    runOnUiThread(() -> tvSent.setText("清零失败: " + e.getMessage()));
                                }
                            }).start();
                        })
                        .setNegativeButton("取消", null)
                        .show();
            });
        });
    }

    private void startRecvThread() {
        new Thread(() -> {
            try {
                recvSocket = new DatagramSocket(LOCAL_RECV_PORT);
                byte[] buf = new byte[1024];
                DatagramPacket packet = new DatagramPacket(buf, buf.length);

                while (isReceiving && !recvSocket.isClosed()) {  // ← 改这里
                    recvSocket.receive(packet);
                    String result = new String(packet.getData(),
                            packet.getOffset(), packet.getLength());
                    String finalResult = result;

                    // ← 把这里改成上面的新代码
                    runOnUiThread(() -> {
                        // 解析数据格式：WATER:OK|SOIL:75|TEMP:25.5
                        String waterStatus = "";
                        String soilMoisture = "";
                        String temperature = "";

                        if (finalResult.contains("|")) {
                            String[] parts = finalResult.split("\\|");
                            for (String part : parts) {
                                if (part.startsWith("WATER:")) {
                                    waterStatus = part.substring(6);
                                } else if (part.startsWith("SOIL:")) {
                                    soilMoisture = part.substring(5);
                                } else if (part.startsWith("TEMP:")) {
                                    temperature = part.substring(5);
                                }
                            }
                        }

                        // 构建显示文本
                        StringBuilder displayText = new StringBuilder();
                        int textColor = 0xFFFFFFFF; // 默认白色

                        // === 第一优先级：水位状态决定基础颜色 ===
                        if (waterStatus.equals("LOW")) {
                            displayText.append("⚠️ 警告：水位过低！\n\n");
                            textColor = 0xFFFF0000; // 水位低=红色（最高优先级，不会被覆盖）
                        } else if (waterStatus.equals("OK")) {
                            displayText.append("💧 水位正常\n\n");
                            textColor = 0xFF00AA00; // 水位正常=绿色（可能被土壤状态覆盖）
                        }

                        // 2. 显示温度
                        if (!temperature.isEmpty()) {
                            displayText.append("🌡️ 温度: ").append(temperature).append("°C\n");
                        }

                        // 3. 显示土壤湿度
                        if (!soilMoisture.isEmpty()) {
                            int moisture = Integer.parseInt(soilMoisture);
                            displayText.append("🌱 土壤湿度: ").append(moisture).append("%\n\n");

                            // === 第二优先级：只有水位正常时，土壤状态才能改变颜色 ===
                            if (waterStatus.equals("OK")) {
                                boolean highTemp = false;
                                if (!temperature.isEmpty()) {
                                    float temp = Float.parseFloat(temperature);
                                    highTemp = temp > 20; // 超过30度算高温
                                }

                                boolean lowMoisture = moisture < 30;

                                if (highTemp && lowMoisture) {
                                    displayText.append("🔥 高温低湿，需要立即浇水！");
                                    textColor = 0xFFFF0000; // 红色（紧急）
                                } else if (lowMoisture) {
                                    displayText.append("💧 土壤干燥，建议浇水");
                                    textColor = 0xFFFF6600; // 橙色（警告）
                                } else if (moisture < 60) {
                                    displayText.append("✓ 土壤湿度适中");
                                    textColor = 0xFF4DB8FF; // 浅蓝色（正常）
                                } else {
                                    displayText.append("✓ 土壤湿润良好");
                                    textColor = 0xFF00AA00; // 绿色（良好）
                                }
                                // 自动浇水否
                                if (highTemp && lowMoisture && waterStatus.equals("OK")) {
                                    displayText.append("\n\n🤖 自动浇水模式已触发");
                                }
                            } else {
                                // 水位低时，只显示土壤状态，不改变颜色
                                if (moisture < 30) {
                                    displayText.append("土壤干燥，无充足水源");
                                } else if (moisture < 60) {
                                    displayText.append("土壤湿度适中");
                                } else {
                                    displayText.append("土壤湿润");
                                }
                            }
                        }

                        // 显示到界面
                        tvRecv.setText(displayText.toString());
                        tvRecv.setTextColor(textColor);
                        tvRecv.setTextSize(18);
                    });
                }
            } catch (Exception e) {
                if (isReceiving) {  // 只有非主动断开才报错
                    e.printStackTrace();
                    runOnUiThread(() -> tvRecv.setText("recv error: " + e.getMessage()));
                }
            } finally {
                if (recvSocket != null && !recvSocket.isClosed()) {
                    recvSocket.close();
                }
            }
        }).start();
    }

    private void sendUdp(String msg) {
        new Thread(() -> {
            DatagramSocket socket = null;
            try {
                InetAddress addr = InetAddress.getByName(RASPI_IP);
                byte[] data = msg.getBytes();
                DatagramPacket packet = new DatagramPacket(data, data.length, addr, RASPI_PORT);
                socket = new DatagramSocket();
                socket.send(packet);
            } catch (Exception e) {
                e.printStackTrace();
                runOnUiThread(() -> tvSent.setText("send error: " + e.getMessage()));
            } finally {
                if (socket != null && !socket.isClosed()) socket.close();
            }
        }).start();
    }
}