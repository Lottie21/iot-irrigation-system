package com.yourteam.smartirrigation;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.ScrollView;
import com.squareup.picasso.Picasso;
import org.json.JSONArray;
import org.json.JSONObject;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class FacePhotosActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        String raspiIp = getIntent().getStringExtra("RASPI_IP");

        ScrollView scrollView = new ScrollView(this);
        GridLayout gridLayout = new GridLayout(this);
        gridLayout.setColumnCount(2);
        gridLayout.setPadding(16, 16, 16, 16);

        scrollView.addView(gridLayout);
        setContentView(scrollView);

        // 加载人脸照片列表
        new Thread(() -> {
            try {
                URL url = new URL("http://" + raspiIp + ":5000/face_photos");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");

                BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                reader.close();

                JSONArray photos = new JSONArray(response.toString());

                runOnUiThread(() -> {
                    if (photos.length() == 0) {
                        TextView tv = new TextView(this);
                        tv.setText("暂无人脸记录");
                        tv.setTextSize(18);
                        gridLayout.addView(tv);
                        return;
                    }

                    for (int i = 0; i < photos.length(); i++) {
                        try {
                            JSONObject photo = photos.getJSONObject(i);
                            String photoUrl = photo.getString("url");
                            String timestamp = photo.getString("timestamp");
                            String filename = photo.getString("filename");

                            // 创建垂直布局（图片+时间戳）
                            android.widget.LinearLayout itemLayout = new android.widget.LinearLayout(this);
                            itemLayout.setOrientation(android.widget.LinearLayout.VERTICAL);
                            GridLayout.LayoutParams layoutParams = new GridLayout.LayoutParams();
                            layoutParams.width = 400;
                            layoutParams.setMargins(8, 8, 8, 8);
                            itemLayout.setLayoutParams(layoutParams);

                            // 图片
                            ImageView imageView = new ImageView(this);
                            android.widget.LinearLayout.LayoutParams imgParams =
                                    new android.widget.LinearLayout.LayoutParams(400, 400);
                            imageView.setLayoutParams(imgParams);
                            imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
                            Picasso.get().load(photoUrl).into(imageView);

                            // 时间戳文字
                            TextView timeText = new TextView(this);
                            String formattedTime = timestamp.substring(0, 8) + " " +
                                    timestamp.substring(9, 11) + ":" +
                                    timestamp.substring(11, 13) + ":" +
                                    timestamp.substring(13, 15);
                            timeText.setText(formattedTime);
                            timeText.setTextSize(12);
                            timeText.setTextAlignment(TextView.TEXT_ALIGNMENT_CENTER);
                            timeText.setPadding(0, 4, 0, 0);

                            itemLayout.addView(imageView);
                            itemLayout.addView(timeText);

                            // 长按删除
                            itemLayout.setOnLongClickListener(view -> {
                                new android.app.AlertDialog.Builder(this)
                                        .setTitle("删除照片")
                                        .setMessage("删除 " + formattedTime + " 的照片？")
                                        .setPositiveButton("删除", (dialog, which) -> {
                                            new Thread(() -> {
                                                try {
                                                    URL deleteUrl = new URL("http://" + raspiIp + ":5000/delete_photo/" + filename);
                                                    HttpURLConnection deleteConn = (HttpURLConnection) deleteUrl.openConnection();
                                                    deleteConn.setRequestMethod("POST");
                                                    deleteConn.getResponseCode();

                                                    runOnUiThread(() -> {
                                                        gridLayout.removeView(view);
                                                        android.widget.Toast.makeText(this, "已删除", android.widget.Toast.LENGTH_SHORT).show();
                                                    });
                                                } catch (Exception e) {
                                                    e.printStackTrace();
                                                }
                                            }).start();
                                        })
                                        .setNegativeButton("取消", null)
                                        .show();
                                return true;
                            });

                            gridLayout.addView(itemLayout);

                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                });

            } catch (Exception e) {
                e.printStackTrace();
                runOnUiThread(() -> {
                    TextView tv = new TextView(this);
                    tv.setText("加载失败: " + e.getMessage());
                    gridLayout.addView(tv);
                });
            }
        }).start();
    }
}